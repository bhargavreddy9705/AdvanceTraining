package problem7;

import java.util.*;
import java.lang.*;
import java.io.*;

class EmptyFieldException extends Exception
{
   
	private static final long serialVersionUID = 1L;
	String message;
    EmptyFieldException(String str)
    {
        message=str;
    }
    public String toString()
    {
        return ("Exception Occured: "+message);
    }
}

class Student
{
 public static void main (String[] args) throws java.lang.Exception
 {
  Scanner sc = new Scanner(System.in);
  String name="Tanmay", Address="Balasore";
  int rollno=0, age=0;
  try
  {
      name=sc.nextLine();
      if(name.equals(""))
      {
          throw new EmptyFieldException("Name can't be empty");
      }
      Address=sc.nextLine();
      if(Address.equals(""))
      {
          
          throw new EmptyFieldException("Address can't be empty");
      }
      rollno=sc.nextInt();
      age = sc.nextInt();
  }
  catch(InputMismatchException e)
  {
      System.out.println("Input Mismatch Exception occured, Enter Integer value for rollno and age");
  }
  catch(EmptyFieldException e)
  {
      System.out.println(e);
  }
  
 }
}
