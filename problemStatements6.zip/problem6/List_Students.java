package problem6;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class List_Students {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ArrayList<String> studName=new ArrayList(); 
		studName.add("studet1");
		studName.add("studet2");
		studName.add("studet3");
		
		System.out.println("Enter the student name to be searched");
		String name=sc.next();
		
		Iterator it=studName.iterator();
		while(it.hasNext()) {
			if(it.next()==name) {
				System.out.println(name +"is present in list");
			}
			
		}
		System.out.println(name+" is not present in list");
	
		

	}

}

