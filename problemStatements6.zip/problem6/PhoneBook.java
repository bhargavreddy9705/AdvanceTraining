package problem6;

import java.util.HashMap;
import java.util.Scanner;

public class PhoneBook {

	public static void main(String[] args) {
		int choice=0;
		HashMap<String, Integer> map = new HashMap<>();
		Scanner sc=new Scanner(System.in);
		
		while(choice!=3) {
			System.out.println(" please select your choice\n 1.Add new phone book entry\n 2.Search Phone Number \n 3.Quite");
			 choice=sc.nextInt();
			switch(choice) {
			case 1:	System.out.println("Please enter the name and number to add");
					String name=sc.next();
					int num=sc.nextInt();
					map.put(name, num);
					break;
			case 2: System.out.println("Please enter the name to get phone number");
					String name1=sc.next();
					if (map.containsKey(name1)) {
						
						 Integer a = map.get(name1);
						 System.out.println("Phone number of"+name1+" "+a);
						
					}
					else {
						System.out.println("Name not found in list");
					}
					break;
			case 3:System.exit(0);
				
			}
		}

	}

}