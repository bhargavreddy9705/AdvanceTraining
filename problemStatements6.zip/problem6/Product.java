package problem6;

public class Product {
	public String product_Id;
	public String product_Name;
	public Product(String product_Id, String product_Name) {
		super();
		this.product_Id = product_Id;
		this.product_Name = product_Name;
	}
	
	

}