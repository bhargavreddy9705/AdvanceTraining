package problem18;

import java.util.HashMap;

public class Repeating_Decimal {
	
	public String fractionToDecimal(int numerator, int denominator) {
        long num = Math.abs((long)numerator);
        long den = Math.abs((long)denominator);
        String sign = (numerator < 0) ^ (denominator < 0) ? "-" : "";
        if (den == 0) {
        	return "";
        } else if (num == 0) {
        	return "0";
        } else if (num % den == 0) {
        	return sign + num/den + "";
        }
        
        HashMap<Long,Integer> map = new HashMap<Long, Integer>();
        StringBuffer rst = new StringBuffer(sign + num/den + ".");
        long end = num%den * 10;
  		int i = 0;
        while (end != 0){
			if (map.containsKey(end)) {
				rst.insert(rst.indexOf(".") + map.get(end) + 1, "(");
				rst.append(")");
				return rst.toString();
			}
			rst.append(end/den);
        	map.put(end, i++);
        	end = (end % den) * 10;
        }
        return rst.toString();
    }
	
	public static void main(String[] args) {
		Repeating_Decimal ass=new Repeating_Decimal();
		String res=ass.fractionToDecimal(1, 6);
		System.out.println(res);
		
		
	}

	

}