package problem5;

public class String_Handling {
public static void main(String[] args) {
	String str="JAVA is Simple";
	int count=0;
	System.out.println(str.toUpperCase());
	System.out.println(str.toLowerCase());
	String[] arrOfStr = str.split(" ", 5);
	for (String a : arrOfStr) {
		System.out.println(a.charAt(0));
	}
	System.out.println(StringFormatter.reverseWord(str));
	for (int j = 0; j <str.length(); j++) {
		
		if(str.charAt(j)!=' ') {
			count++;
		}
	}
	System.out.println(count);
	 
}


public static class StringFormatter {  
public static String reverseWord(String str){  
    String words[]=str.split("\\s");  
    String reverseWord="";  
    for(String w:words){  
        StringBuilder sb=new StringBuilder(w);  
        sb.reverse();  
        reverseWord+=sb.toString()+" ";  
    }  
    return reverseWord.trim();  
}  
}   
}