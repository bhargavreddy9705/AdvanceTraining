package problem12;

import java.util.Arrays;

public class First_Repeat {
	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 10, 6, 4, 3, 7, 10};
		Arrays.sort(arr);
		for (int i = 0; i < arr.length-1; i++) {
			if(arr[i]==arr[i+1]) {
				System.out.println("The First Repeating element is "+ arr[i]);
				break;
			}
		}
		
	}
	
}
