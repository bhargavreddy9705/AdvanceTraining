package problem2;

import java.util.Scanner;
public class Sequence {
		public static void main(String[] args) {
			int a,b;
			int[] res=new int[15];
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the 2 numbers");
			a=sc.nextInt();
			b=sc.nextInt();
			res[0]=a;
			res[1]=b;
			for(int i=2;i<15;i++) {
				res[i]=res[i-1]+res[i-2];
				
			}
			
			for(int i=0;i<res.length;i++) {
				System.out.print(res[i]+" ");
			}
			

		}

	
}
