package problem2;

public class Problem2_3 {
	public static void main(String[] args) {
		int[] A= {3,2,4,5,6,4,5,7,3,2,3,4,7,1,2,0,0,0};
		int sum=0,sum1=0,avg=0,small=0;
		for(int i=0;i<15;i++) {
			sum+=A[i];			
		}
		A[15]=sum;
		
		for(int i=0;i<A.length;i++) {
				sum1+=A[i];		
		}
		A[16]=(int)(sum1/A.length);
		
		small=A[0];
		for(int i=0;i<A.length;i++) {
			if(A[i] < small) {
				small=A[i];
					
			}
			A[17]=small;
			
		}
		
		for(int i=0;i<A.length;i++) {
			System.out.print(A[i]+" ");
		}

	}

}
