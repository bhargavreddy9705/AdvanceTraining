package problem1;

public class Problem1_4 {

	int length=1;
	 int width=1;
	 int calArea() {
		 return length*width;
	 }
	 int calPerimeter() {
		 return 2*(length+width);
	 }
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		if(length>0&&length<20)
		this.length = length;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if(width>0&&width<20)
		this.width = width;
	}
	 
	 
}
	
