package problem1;

public class Book {
	private String book_tittle;
	private float price;
	public String getBook_tittle() {
		return book_tittle;
	}
	public void setBook_tittle(String book_tittle) {
		this.book_tittle = book_tittle;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	

}