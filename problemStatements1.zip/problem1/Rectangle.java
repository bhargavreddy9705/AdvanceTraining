package problem1;

public class Rectangle {
	
 int length;
 int breadth;
	
	public Rectangle(int length, int breadth) {
		//super();
		this.length = length;
		this.breadth = breadth;
	}
	
	public double area(int length,int breadth) {
		return (this.length*this.breadth);
	}
	public void display() {
		System.out.println("The area  of rectangle whose length "+ length+" and breadth "+ breadth+" is "+area(length, breadth));
	}


	

}
