package problem1;

public class Test_Problem1_4 {
	public static void main(String[] args) {
		
		Problem1_4 pb=new Problem1_4();
		pb.setLength(3);
		pb.setWidth(10);
		
		System.out.println(pb.calArea());
		System.out.println(pb.calPerimeter());
	}
}
