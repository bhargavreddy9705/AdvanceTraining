package problem1;

public class book1 {

	Book b1=new Book();
	Book b2=new Book();
	public static void main(String[] args) {
		book1 p=new book1();
		
		p.createBooks();
		p.display();

	}
	public void createBooks() {
	
			  b1.setBook_tittle("Java Programming");
			  b1.setPrice(350.50f);
			  b2.setBook_tittle("Let Us C");
			  b2.setPrice(200.00f);
			
		
		
	}
	public void display() {
		//Book b=new Book();
		
			  
			System.out.println(b1.getBook_tittle());
			System.out.println(b1.getPrice());
			System.out.println(b2.getBook_tittle());
			System.out.println(b2.getPrice());
			
	}

}