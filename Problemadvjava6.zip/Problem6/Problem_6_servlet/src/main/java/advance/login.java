package advance;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
  

public class login {
	public static boolean validate(int uname,String pass){  
		boolean status=false;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost/prodctDB?characterEncoding=latin1","root","admin");  
		System.out.println("Sccessfully connected");
		      
		PreparedStatement ps=con.prepareStatement("select * from users where uname=? and pass=?");  
		ps.setInt(1,uname);  
		ps.setString(2,pass);  
		      
		ps.executeQuery();
		 status=true; 
		          
		}catch(Exception e){System.out.println(e);}  
		return status;  
		} 
	
	public static boolean insert(String first_name,String address,String email,String uname,String pass,String regdate){  
		boolean status=false;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost/prodctDB?characterEncoding=latin1","root","admin");  
		System.out.println("Sccessfully connected");
		      
		PreparedStatement ps=con.prepareStatement("insert into users values(?,?,?,?,?,?)");  
		ps.setString(1,first_name);  
		ps.setString(2,address); 
		ps.setString(3, email);
		ps.setInt(4,Integer.parseInt(uname));
		ps.setString(5, pass);
		ps.setString(6, regdate);
		
		      
		ps.executeUpdate(); 
		
		 status=true;        
		}catch(Exception e){System.out.println(e);}  
		return status;  
		} 
	
	public static boolean searchById(int num) throws Exception {
		boolean status=false;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost/prodctDB?characterEncoding=latin1","root","admin");  
		System.out.println("Sccessfully connected");
		      
		PreparedStatement ps=con.prepareStatement("SELECT * FROM book WHERE book_id=?");  
		ps.setInt(1,num);  
		
		      
		ps.executeQuery(); 
		
		 status=true;        
		}catch(Exception e){System.out.println(e);}  
		return status;  
	

}
}
