package advance;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servlet2
 */
@WebServlet("/servlet2")
public class servlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		  String n=request.getParameter("first_name");  
		 String p=request.getParameter("address");
		 String e=request.getParameter("email");
		 String u=request.getParameter("uname");
		 String pd=request.getParameter("pass");
		 String rd1=request.getParameter("regdate");
		 
		 
		 
		 if(login.insert(n, p,e,u,pd,rd1)){
			 	System.out.println("Registered Successfully");
		        RequestDispatcher rd=request.getRequestDispatcher("login.jsp");  
		        rd.forward(request,response);  
		    }  
			
			  else{ System.out.println("Not registered sucessfully"); RequestDispatcher
			  rd=request.getRequestDispatcher("register.jsp");
			  rd.include(request,response); }
			 
	}

}
