package com.shoppingcart.dao;

import java.io.DataInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mycompany.dbutil.DBUtil;

public class ShopManagmentDao {
	static Scanner sc = new Scanner(System.in);

	public static void query() throws Exception {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from Books order by Book_id asc";
		Statement st = conn.createStatement();
		ResultSet rt = st.executeQuery(sql);
		System.out.println("BookId" + "\t" + "BookName" + "\t" + "Author"+"\t" + "price");
		while (rt.next()) {
			System.err.println(rt.getInt("Book_id") + "\t" + rt.getString("Book_name") + "\t" + rt.getString("Author") + "\t "
					+ rt.getInt("Price"));
		}
	}
	public static void query1() throws Exception {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from User order by first_name asc";
		Statement st = conn.createStatement();
		ResultSet rt = st.executeQuery(sql);
		System.out.println("FirstName" + "\t" + "Address" + "\t" + "Email"+"\t" + "Uname"+"\t"+"Password" + "\t" + "RegDate");
		while (rt.next()) {
			System.err.println(rt.getString("first_name") + "\t" + rt.getString("adress") + "\t" + rt.getString("email") + "\t "
					+ rt.getString("pass")+ "\t" + rt.getString("regdate"));
		}
	}
	public static void query2() throws Exception {
		Connection conn = DBUtil.getConnection();
		String sql = "select * from Orders order by orderId asc";
		Statement st = conn.createStatement();
		ResultSet rt = st.executeQuery(sql);
		System.out.println("OrderId" + "\t" + "Address" + "\t" + "MobileNo"+"\t" + "Name"+"\t"+"OrderDate" + "\t" + "Quantity");
		while (rt.next()) {
			System.err.println(rt.getInt("orderId") + "\t" + rt.getString("adress") + "\t" + rt.getInt("mobileno") +"\t" + rt.getString("order_date")+ "\t "
					+ rt.getString("name")+ "\t" + rt.getInt("quantity"));
		}
	}

	public static void insert() throws Exception {
		Connection conn = DBUtil.getConnection();
	
		DataInputStream KB = new DataInputStream(System.in);

	
		System.out.print("Enter Book ID: ");
		String Pid = KB.readLine();
		
		System.out.print("Enter Book Name: ");
		String Pn = KB.readLine();
	
		System.out.print("Enter Book Author: ");
		String Pa = KB.readLine();
		
		System.out.print("Enter Book Price: ");
		String Pp = KB.readLine();

		PreparedStatement smt = conn.prepareStatement("insert into Books values(?,?,?,?)");

		
		smt.setInt(1, Integer.parseInt(Pid));
		smt.setString(2, Pn);
		smt.setString(3, (Pa));
		smt.setInt(4, Integer.parseInt(Pp));
		smt.executeUpdate();

	}
	public static void insert1() throws Exception {
		Connection conn = DBUtil.getConnection();
		
		DataInputStream KB = new DataInputStream(System.in);
		
		
		System.out.print("Enter First Name: ");
		String Pfn = KB.readLine();
		
		System.out.print("Enter Adress: ");
		String Pa = KB.readLine();
		
		System.out.print("Enter Email: ");
		String Pe = KB.readLine();
		
		System.out.print("Enter Username: ");
		String Pu = KB.readLine();
		
		System.out.print("Enter Password: ");
		String Pp = KB.readLine();
		
		System.out.print("Enter RegDate: ");
		String Pr = KB.readLine();
		
		PreparedStatement smt = conn.prepareStatement("insert into User values(?,?,?,?,?,?)");
		
		
		smt.setString(1, Pfn);
		smt.setString(2, Pa);
		smt.setString(3, Pe);
		smt.setString(4, Pu);
		smt.setString(5, Pp);
		smt.setString(6, Pr);
		smt.executeUpdate();
		
	}
	public static void insert2() throws Exception {
		Connection conn = DBUtil.getConnection();
		
		DataInputStream KB = new DataInputStream(System.in);
		
		System.out.print("Enter OrderId: ");
		String Poi = KB.readLine();
		
		System.out.print("Enter Adress: ");
		String Pa = KB.readLine();
		
		System.out.print("Enter MobileNO: ");
		String Pm = KB.readLine();
		
		System.out.print("Enter Name: ");
		String Pn = KB.readLine();
		
		System.out.print("Enter OrderDate: ");
		String Po = KB.readLine();
		
		System.out.print("Enter Quantity: ");
		String Pq = KB.readLine();
		
		PreparedStatement smt = conn.prepareStatement("insert into Orders values(?,?,?,?,?,?)");
		
		
		smt.setInt(1, Integer.parseInt(Poi));
		smt.setString(2, Pa);
		smt.setInt(3, Integer.parseInt(Pm));
		smt.setString(4, Pn);
		smt.setString(5, Po);
		smt.setInt(6, Integer.parseInt(Pq));
		smt.executeUpdate();
		
	}

	
	
}
