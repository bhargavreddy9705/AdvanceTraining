package com.shoppingcart.domain;

public class Order_Details {

	private int orderId;
    private String adress;
    private int mobileno;
    private String name ;
    private String order_date;
    private int quantity;
	public Order_Details(int orderId, String adress, int mobileno, String name, String order_date, int quantity) {
		super();
		this.orderId = orderId;
		this.adress = adress;
		this.mobileno = mobileno;
		this.name = name;
		this.order_date = order_date;
		this.quantity = quantity;
	}
	public Order_Details() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Order_Details [orderId=" + orderId + ", adress=" + adress + ", mobileno=" + mobileno + ", name=" + name
				+ ", order_date=" + order_date + ", quantity=" + quantity + "]";
	}
    
    
	
}
