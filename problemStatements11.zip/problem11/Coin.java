package problem11;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Vector;

public class Coin {
	
	 static int deno[] = {1, 2, 5, 10, 20, 
			    50, 100, 500,2000};
			    static int n = deno.length;
			  
			    static int  findMin(int V)
			    {			        
			        HashSet<Integer> ans = new HashSet<>();			          
			        for (int i = n - 1; i >= 0; i--)
			        {			           
			            while (V >= deno[i]) 
			            {
			                V -= deno[i];
			                ans.add(deno[i]);
			            }
			        } 
			        //System.out.println(ans);
			        return ans.size();
			        
			    }

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value for V");
		int n = sc.nextInt();
        System.out.print("Minimal Output is:"+findMin(n));
        

	}

}