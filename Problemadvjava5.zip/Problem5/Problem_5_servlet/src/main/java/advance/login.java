package advance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class login {
	
	public static boolean validate(int uname,String pass){  
		boolean status=false;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost/prodctDB?characterEncoding=latin1","root","admin");  
		System.out.println("Sccessfully connected");
		      
		PreparedStatement ps=con.prepareStatement("select * from users where uname=? and pass=?");  
		ps.setInt(1,uname);  
		ps.setString(2,pass);  
		      
		
		status=true;
		          
		}catch(Exception e){System.out.println(e);}  
		return status;  
		} 
	
	public static boolean update(String pass,int uname){  
		boolean status=false;  
		try{  
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
				"jdbc:mysql://localhost/prodctDB?characterEncoding=latin1","root","admin");  
		System.out.println("Sccessfully connected1");
		      
		PreparedStatement ps=con.prepareStatement("UPDATE users SET pass = ? WHERE uname = ?");  
		ps.setString(1,pass); 
		ps.setInt(2,uname); 
		      
		ps.executeUpdate();  
		status=true;
		          
		}catch(Exception e){System.out.println(e);}  
		return status;  
		} 

	
	

}
