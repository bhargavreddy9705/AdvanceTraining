package problem4;

import java.util.Scanner;

public class Bank_Acount1 {

	public static void main(String[] args) {
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		Bank_Account2 book1 = new Bank_Account2(100, "abcdef", "savings", 10000);
		// BankAccount book2=new BankAccount(101,"xyz","current",20000);

		while (choice != 4) {
			System.out.println("Please select your choice 1.deposite\t 2.withdraw\t 3.getBalance\t 4.exit");
			choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter the amount to be deposite");
				float b1 = sc.nextFloat();
				book1.deposit(b1);
				break;
			case 2:
				System.out.println("Enter the amount to be withdraw");
				float b = sc.nextFloat();
				book1.withdraw(b);
				break;

			case 3:
				System.out.println("Printing balance");
				int a = (int) book1.getBalance();
				System.out.println(a);
				break;

			case 4:
				System.exit(0);

			}
		}
	}
}
