package problem8;
class Counter1 implements Runnable {

	Storage1 st;

	public Counter1(Storage1 st2) {
		st = st2;
	}

	@Override
	public void run() {
		synchronized (st) {
			for (int i = 0; i < 10; i++) {
				while (!st.isPrinted()) { 
					try {
						st.wait();
					} catch (Exception e) {
					}
				}
				st.setValue(i);
				st.setPrinted(false);
				st.notify();
			}
		}
	}

}

class Printer1 implements Runnable {
	Storage1 st;

	public Printer1(Storage1 st2) {
		this.st = st2;
	}

	@Override
	public void run() {
		synchronized (st) {
			for (int i = 0; i < 10; i++) {
				while (st.isPrinted()) { 
					try {
						st.wait();
					} catch (Exception e) {
					}
				}
				System.out.println(Thread.currentThread().getName() + " " + st.getValue());
				st.setPrinted(true);
				st.notify();
			}
		}
	}

}

class Storage1 {
	int i;
	boolean printed = true;

	public void setValue(int i) {
		this.i = i;
	}

	public int getValue() {
		return this.i;
	}

	public boolean isPrinted() {
		return printed;
	}

	public void setPrinted(boolean p) {
		printed = p;
	}
}

public class AddSynchronization {
	public static void main(String[] args) {
		Storage1 st = new Storage1();
		Counter1 c = new Counter1(st);
		Printer1 p = new Printer1(st);
		new Thread(c, "Counter1").start();
		new Thread(p, "Printer1").start(); 
	}

}

